#!/bin/bash
set -e

echo 'packer' | echo "------------------------------------------------------------------"
echo 'packer' | echo "Start backing Liftr data plane SBI image ..."
echo 'packer' | echo "------------------------------------------------------------------"

echo 'packer' | echo "******************************************************************"
echo 'packer' | echo "Finished backing Liftr data plane SBI image"
echo 'packer' | echo "******************************************************************"