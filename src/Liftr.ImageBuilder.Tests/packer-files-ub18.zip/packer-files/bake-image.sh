#!/bin/bash
set -e

# It is highly recommend to have some special characters to mark the start of the script,
# e.g. '[bake-image.sh | start]'. Then it will be easy to search in the AIB packer logs.
# Details: https://aka.ms/liftr/aib-tsg
echo "------------------------------------------------------------------------------------------"
echo "[liftr-image-builder] [bake-image.sh | start] Start backing VM image ..."
echo "------------------------------------------------------------------------------------------"

echo "******************************************************************************************"
echo "[liftr-image-builder] [bake-image.sh | end] Finished backing VM image ..."
echo "******************************************************************************************"